"""The Israeli VOD catalogue.

A flat index of programmes across the Israeli broadcasters, used for three
things: browsing by channel, feeding the universal search, and supplying the
local half of the search autocomplete.

Entries are stored with short keys because there are a few thousand of them and
they live in the cache. The long names are restored on the way out, so nothing
else in the add-on has to know about the compact form.

    n  name        u  url or id     i  icon
    d  description m  module        o  mode      c  category

The index and its per-broadcaster URL formats were derived from the Idan Plus
add-on by Fishenzon (github.com/Fishenzon/repo), which is where the Kodi POV IL
build gets its Israeli catalogue.
"""
import html
import json
import os

from .. import cache, http, kodi, settings
from ..meta import items

INDEX_TTL = 7 * 24 * 3600

# Broadcaster labels, so a row heading reads like a channel name.
MODULE_NAMES = {
    "kan": u"\u05db\u05d0\u05df",
    "keshet": u"\u05e7\u05e9\u05ea 12",
    "reshet": u"\u05e8\u05e9\u05ea 13",
    "sport5": u"\u05e1\u05e4\u05d5\u05e8\u05d8 5",
    "sport1": u"\u05e1\u05e4\u05d5\u05e8\u05d8 1",
    "14tv": u"\u05e2\u05e8\u05d5\u05e5 14",
    "891fm": "891FM",
}


def index_url():
    return settings.get("vod.series_url", "").strip()


def seed_path():
    return os.path.join(kodi.addon_path(), "resources", "data", "vod_series.json")


def cache_key():
    return cache.make_key("vod", "series", _seed_stamp(seed_path()))


def _seed_stamp(path):
    """A marker that changes when the bundled data changes.

    Without this, updating the shipped list has no effect until the cache
    expires, so a data fix appears not to work for a day. Folding the file
    size and modification time into the cache key makes a new bundle
    invalidate the old copy immediately.
    """
    try:
        stat = os.stat(path)
        return "%d-%d" % (stat.st_size, int(stat.st_mtime))
    except OSError:
        return "none"


def load():
    """The whole index, from the remote list or the bundled seed."""
    cached = cache.get(cache_key())
    if cached is not None:
        return cached
    data = _readable(_fetch_remote() or _read_seed())
    if data:
        cache.set(cache_key(), data, INDEX_TTL)
    return data or []


def _readable(entries):
    """Text as a person should see it, not as the page stored it.

    The broadcasters' own pages are scraped, so their HTML entities travel
    into the catalogue and out again: "ירדן ודידי בפיג&#x27;מה" is a real
    programme in Kan's children's section, and that is exactly what the row
    said.

    It happens here, on the one path everything comes through, rather than in
    _to_item. Search matches on the stored name and by_category compares
    against the stored category, so cleaning only on the way to the screen
    would leave those two matching text nobody can type. Cleaning once means
    the cached copy is already clean and the warm path costs nothing.
    """
    for entry in entries or []:
        for key in ("n", "d", "c"):
            value = entry.get(key)
            if value and "&" in value:
                entry[key] = html.unescape(value)
    return entries


def _fetch_remote():
    url = index_url()
    if not url:
        return None
    payload = http.get_json(url, timeout=(5, 15), default=None)
    if isinstance(payload, list) and payload:
        kodi.log("loaded %d VOD titles from the remote index" % len(payload))
        return payload
    return None


def _read_seed():
    try:
        with open(seed_path(), encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        kodi.log("no bundled VOD index available")
        return []


def refresh():
    cache.delete(cache_key())
    return load()


# --------------------------------------------------------------------------
# converting to items
# --------------------------------------------------------------------------


def _to_item(entry):
    from .. import router

    # `or ""` rather than a get default: a JSON null is a present key, so the
    # default never fires and `icon.startswith` was one null away from taking
    # down the whole catalogue.
    module = entry.get("m") or ""
    icon = entry.get("i") or ""
    if icon.startswith("/"):
        # Kan stores relative poster paths against its own host.
        icon = "https://kan.org.il" + icon
    ref = entry.get("u") or ""
    mode = entry.get("o") or ""

    return items.new_item(
        "vod",
        ids={"vod": "%s:%s" % (module, ref)},
        title=entry.get("n") or "",
        plot=entry.get("d") or "",
        art={"poster": icon, "thumb": icon},
        studio=[MODULE_NAMES.get(module, module)],
        extra={
            "url": router.url_for("vod_show", module=module, ref=ref, mode=mode),
            "module": module,
            "mode": mode,
            "category": entry.get("c") or "",
            "ref": ref,
        },
    )


def all_titles():
    """Every programme, used to build the search autocomplete index."""
    return [_to_item(entry) for entry in load()]


def modules():
    """Broadcasters present in the index, with how many programmes each has."""
    counts = {}
    for entry in load():
        module = entry.get("m", "")
        counts[module] = counts.get(module, 0) + 1
    return sorted(counts.items(), key=lambda kv: -kv[1])


def by_module(module, limit=None):
    entries = [e for e in load() if e.get("m") == module]
    entries.sort(key=lambda e: e.get("n", ""))
    result = [_to_item(entry) for entry in entries]
    return result[:limit] if limit else result


def categories(module=None):
    found = {}
    for entry in load():
        if module and entry.get("m") != module:
            continue
        name = entry.get("c") or ""
        if name:
            found[name] = found.get(name, 0) + 1
    return sorted(found.items(), key=lambda kv: -kv[1])


def by_category(name, module=None, limit=None):
    """Programmes in one category, optionally within one broadcaster.

    `module` is not optional in practice. Categories are counted per
    broadcaster - the list reads "Drama (12)" under Kan - so a category
    opened without it returned every broadcaster's drama, which is both a
    different list and a longer one than the number beside it promised.
    """
    entries = [e for e in load()
               if (e.get("c") or "") == name
               and (not module or e.get("m") == module)]
    entries.sort(key=lambda e: e.get("n") or "")
    result = [_to_item(entry) for entry in entries]
    return result[:limit] if limit else result


def search(query, limit=20):
    """Substring search over programme names, Hebrew or Latin.

    Prefix matches come first because they are what someone typing a title
    expects, then anything containing the text.
    """
    needle = (query or "").strip().lower()
    if len(needle) < 2:
        return []

    starts, contains = [], []
    for entry in load():
        name = (entry.get("n") or "").lower()
        if not name:
            continue
        if name.startswith(needle):
            starts.append(entry)
        elif needle in name:
            contains.append(entry)
        if len(starts) >= limit:
            break

    return [_to_item(entry) for entry in (starts + contains)[:limit]]


def newest_episodes(limit=20):
    """A browsable row for the home screen.

    The index carries no air dates, so this is a stable sample across the
    broadcasters rather than a genuine "newest" list, which is why it is
    presented as a catalogue row and not as a recency claim.
    """
    per_module = max(1, limit // max(1, len(MODULE_NAMES)))
    out = []
    for module, _count in modules():
        out.extend(by_module(module, per_module))
        if len(out) >= limit:
            break
    return out[:limit]


def get(module, ref):
    for entry in load():
        if entry.get("m") == module and str(entry.get("u")) == str(ref):
            return _to_item(entry)
    return None
